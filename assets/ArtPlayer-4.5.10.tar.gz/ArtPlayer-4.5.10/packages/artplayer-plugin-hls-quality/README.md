# artplayer-plugin-hls-quality

Hls quality plugin for ArtPlayer

## Demo

[https://artplayer.org](https://artplayer.org/?libs=https://cdnjs.cloudflare.com/ajax/libs/hls.js/8.0.0-beta.3/hls.min.js%0A./uncompiled/artplayer-plugin-hls-quality/index.js&example=hls.quality)

## Usage

[https://artplayer.org/document/en/Plugins/hls-quality](https://artplayer.org/document/en/Plugins/hls-quality)

## License

MIT © Harvey Zack
