# ArtPlayer

🎨 ArtPlayer.js is a modern and full featured HTML5 video player

## Github

[https://github.com/zhw2590582/ArtPlayer](https://github.com/zhw2590582/ArtPlayer)

## Home Page

[https://artplayer.org](https://artplayer.org)

## License

MIT © Harvey Zack
