# artplayer-plugin-ads

Ads plugin for ArtPlayer

## Demo

[https://artplayer.org](https://artplayer.org/?libs=./uncompiled/artplayer-plugin-ads/index.js&example=ads)

## Usage

[https://artplayer.org/document/en/Plugins/ads](https://artplayer.org/document/en/Plugins/ads)

## License

MIT © Harvey Zack
