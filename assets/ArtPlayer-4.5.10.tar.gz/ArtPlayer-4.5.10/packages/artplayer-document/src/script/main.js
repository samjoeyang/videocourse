if (typeof window !== 'undefined') {
    require('./bugfix');
}
