# artplayer-tool-thumbnail

Thumbnail tool for ArtPlayer

## Demo

[https://artplayer.org](https://artplayer.org/?libs=./uncompiled/artplayer-tool-thumbnail/index.js&example=thumbnail)

## License

MIT © Harvey Zack
