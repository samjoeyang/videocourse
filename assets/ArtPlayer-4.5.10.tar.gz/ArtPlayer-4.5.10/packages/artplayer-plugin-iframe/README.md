# artplayer-plugin-iframe

Iframe plugin for ArtPlayer

## Demo

[https://artplayer.org](https://artplayer.org/?libs=./uncompiled/artplayer-plugin-iframe/index.js&example=iframe)

## Usage

[https://artplayer.org/document/en/Plugins/iframe](https://artplayer.org/document/en/Plugins/iframe)

## License

MIT © Harvey Zack
