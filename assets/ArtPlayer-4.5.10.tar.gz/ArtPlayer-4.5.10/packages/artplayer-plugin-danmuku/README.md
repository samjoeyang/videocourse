# artplayer-plugin-danmuku

Danmuku plugin for ArtPlayer

## Demo

[https://artplayer.org](https://artplayer.org/?libs=./uncompiled/artplayer-plugin-danmuku/index.js&example=danmuku)

## Usage

[https://artplayer.org/document/en/Plugins/danmuku](https://artplayer.org/document/en/Plugins/danmuku)

## License

MIT © Harvey Zack
