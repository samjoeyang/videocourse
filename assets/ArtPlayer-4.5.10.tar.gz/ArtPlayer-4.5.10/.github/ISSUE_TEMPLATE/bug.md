---
name: Bug report
about: Report an issue or unexpected behaviour with Artplayer
---

### Expected behaviour

### Actual behaviour

### Steps to reproduce

### Environment

-   Browser:
-   Version:
-   Operating System:
-   Version:

### Console errors (if any)

### Link to where the bug is happening
