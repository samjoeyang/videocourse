import Artplayer from '../packages/artplayer/dist/artplayer.js';
console.log(Artplayer.default.html);
